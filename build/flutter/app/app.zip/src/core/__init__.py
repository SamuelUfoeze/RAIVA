"""
Core application components
"""
