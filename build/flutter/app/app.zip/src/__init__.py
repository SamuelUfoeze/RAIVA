"""
Personal Operating System - Source Package
"""

__version__ = "1.0.0"
__author__ = "Personal OS Team"
__description__ = "An integrated personal operating system for productivity and knowledge management"
